package entity

// User 服务端配置
type User struct {
	Username string
	Password string
}
