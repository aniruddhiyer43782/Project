package entity

// BackupResult BackupResult
type BackupResult struct {
	ProjectName string // 项目名称
	FileName    string
	FileSize    string
	Result      string
}
